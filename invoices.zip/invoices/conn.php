<?php
$conn = mysqli_connect("localhost","uzair","uzair118","Uzair");
 //$conn = mysqli_connect("85.10.205.173:3306","uzair118","uzair118","uzairdb");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>
